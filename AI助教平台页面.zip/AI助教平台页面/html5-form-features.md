# AI 助教平台登录/注册页使用的 HTML5 表单增强与新特性说明

本文档说明了在登录页与注册页中运用了哪些 HTML5 表单增强特性和新特性，帮助开发者和设计者理解页面的交互与校验方式。

## 一、HTML5 表单增强特性

### 1. required
- 作用：让表单字段在提交时必须填写。
- 应用场景：用户名、邮箱、手机号、密码、确认密码、记住我等关键字段。
- 示例：
  ```html
  <input type="text" required>
  ```

### 2. autofocus
- 作用：页面加载后自动聚焦到指定输入框。
- 应用场景：登录页用户名输入框默认获得焦点，提升用户体验。
- 示例：
  ```html
  <input type="text" autofocus>
  ```

### 3. autocomplete
- 作用：浏览器自动填充用户之前输入过的信息。
- 常见值：
  - username
  - email
  - tel
  - current-password
  - new-password
- 应用场景：
  - 注册用户名使用 autocomplete="username"
  - 邮箱使用 autocomplete="email"
  - 手机号使用 autocomplete="tel"
  - 登录密码使用 autocomplete="current-password"
  - 注册密码使用 autocomplete="new-password"
- 示例：
  ```html
  <input type="email" autocomplete="email">
  ```

### 4. placeholder
- 作用：在输入框中显示提示文本，用户输入前展示信息。
- 应用场景：用户名、邮箱、手机号、密码提示。
- 示例：
  ```html
  <input type="password" placeholder="请输入密码">
  ```

### 5. minlength / maxlength
- 作用：限制字段最小和最大长度。
- 应用场景：
  - 用户名：3~20 位
  - 密码：至少 6 位，最多 20 位
  - 手机号：最大长度为 11
- 示例：
  ```html
  <input type="text" minlength="3" maxlength="20">
  ```

### 6. type="email"
- 作用：浏览器原生校验邮箱格式。
- 应用场景：注册页邮箱字段。
- 示例：
  ```html
  <input type="email" required>
  ```

### 7. type="tel"
- 作用：适用于电话号码输入，便于移动端键盘识别。
- 应用场景：注册页手机号字段。
- 示例：
  ```html
  <input type="tel" pattern="^1[3-9]\d{9}$">
  ```

### 8. type="password"
- 作用：输入内容不显示明文，适合密码输入。
- 应用场景：登录和注册页面的密码字段。
- 示例：
  ```html
  <input type="password" required>
  ```

### 9. type="checkbox"
- 作用：复选框输入控件，用于“记住我”和“同意协议”场景。
- 应用场景：登录页记住我，注册页协议确认。
- 示例：
  ```html
  <input type="checkbox" required>
  ```

### 10. pattern
- 作用：使用正则表达式限制输入内容。
- 应用场景：
  - 用户名：中文、字母、数字、下划线
  - 手机号：国内 11 位手机号
  - 密码：6 位以上且包含字母和数字
- 示例：
  ```html
  <input type="text" pattern="^[A-Za-z0-9_\u4e00-\u9fa5]{3,20}$">
  <input type="tel" pattern="^1[3-9]\d{9}$">
  <input type="password" pattern="^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,20}$">
  ```

### 11. form.reportValidity()
- 作用：在脚本中强制触发浏览器原生校验提示。
- 应用场景：注册页提交时主动触发提示信息并阻止非法提交。
- 示例：
  ```js
  form.reportValidity();
  ```

---

## 二、HTML5 新特性与语义增强

### 1. 语义化结构标签
- 使用了结构化标签：
  - main
  - aside
  - form
  - button
- 作用：提高语义清晰度、便于屏幕阅读器识别和代码维护。

### 2. CSS3 与现代布局能力
- 使用了：
  - flex
  - grid
  - border-radius
  - box-shadow
  - rgba 透明色
  - 渐变色 background: linear-gradient()
- 作用：提升页面视觉效果和整体布局体验。

### 3. 现代输入体验
- 通过 inputmode 属性提升移动端输入体验。
- 示例：
  ```html
  <input type="tel" inputmode="numeric">
  ```
- 作用：在移动端键盘中显示更适合数字输入的键盘。

### 4. 表单校验和反馈
- 浏览器自带校验样式和提示逻辑。
- 通过 :valid 和 :invalid 伪类对字段状态进行视觉反馈。
- 示例：
  ```css
  input:valid {
    border-color: rgba(31, 170, 115, 0.7);
  }

  input:invalid:not(:placeholder-shown) {
    border-color: rgba(231, 76, 60, 0.7);
  }
  ```
- 作用：用户输入合法/非法时有即时视觉状态反馈。

---

## 三、表单字段具体应用

### 登录页字段
- 用户名：
  - required
  - minlength / maxlength
  - pattern
  - autocomplete="username"
  - autofocus
- 密码：
  - required
  - minlength / maxlength
  - pattern
  - autocomplete="current-password"
- 记住我：
  - type="checkbox"

### 注册页字段
- 用户名：
  - required
  - minlength / maxlength
  - pattern
  - autocomplete="username"
- 邮箱：
  - type="email"
  - required
  - autocomplete="email"
- 手机号：
  - type="tel"
  - required
  - pattern
  - maxlength
  - autocomplete="tel"
- 密码：
  - type="password"
  - required
  - minlength / maxlength
  - pattern
  - autocomplete="new-password"
- 确认密码：
  - type="password"
  - required
  - minlength / maxlength
  - pattern
  - autocomplete="new-password"
- 用户协议：
  - type="checkbox"
  - required

---

## 四、总结

这两个页面综合使用了 HTML5 的表单增强功能，重点体现了：
- 语义化表单结构
- 原生表单校验
- 更清晰的用户输入体验
- 强校验规则与更良好的交互反馈
- 兼容现代浏览器的标准化输入方式

通过使用这些机制，可以减少前端脚本校验代码，提高页面质量，并让用户体验更自然、更稳定。
